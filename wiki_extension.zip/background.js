chrome.runtime.onInstalled.addListener(() => {
    console.log("Thanks for installing the AoC wiki extension");
});